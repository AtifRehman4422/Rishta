/**
 * Renames MySQL database pk_rishta_db → pkrishta_pk_rishta_db
 * by creating the new DB and moving all tables.
 * Usage: node database/rename-database.js
 */
require('dotenv').config();
const mysql = require('mysql2/promise');

const OLD_NAME = 'pk_rishta_db';
const NEW_NAME = 'pkrishta_pk_rishta_db';

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '3306', 10),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    multipleStatements: true,
  });

  try {
    const [oldRows] = await conn.query('SHOW DATABASES LIKE ?', [OLD_NAME]);
    const [newRows] = await conn.query('SHOW DATABASES LIKE ?', [NEW_NAME]);

    if (!oldRows.length && newRows.length) {
      console.log(`Already using ${NEW_NAME}. Nothing to rename.`);
      return;
    }

    if (!oldRows.length && !newRows.length) {
      await conn.query(
        `CREATE DATABASE \`${NEW_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
      );
      console.log(`Created empty database ${NEW_NAME} (old DB not found).`);
      return;
    }

    if (oldRows.length && newRows.length) {
      console.log(`${NEW_NAME} already exists. Skipping move. Drop ${OLD_NAME} manually if unused.`);
      return;
    }

    await conn.query(
      `CREATE DATABASE \`${NEW_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
    );

    const [tables] = await conn.query(
      `SELECT table_name AS name
       FROM information_schema.tables
       WHERE table_schema = ?
         AND table_type = 'BASE TABLE'`,
      [OLD_NAME]
    );

    for (const row of tables) {
      const table = row.name || row.TABLE_NAME || row.Name;
      await conn.query(
        `RENAME TABLE \`${OLD_NAME}\`.\`${table}\` TO \`${NEW_NAME}\`.\`${table}\``
      );
      console.log(`Moved table: ${table}`);
    }

    // Move views if any
    const [views] = await conn.query(
      `SELECT table_name AS name
       FROM information_schema.tables
       WHERE table_schema = ?
         AND table_type = 'VIEW'`,
      [OLD_NAME]
    );
    for (const row of views) {
      const view = row.name || row.TABLE_NAME || row.Name;
      const [defs] = await conn.query(
        `SELECT VIEW_DEFINITION AS def
         FROM information_schema.views
         WHERE table_schema = ? AND table_name = ?`,
        [OLD_NAME, view]
      );
      if (defs[0]?.def) {
        await conn.query(`CREATE OR REPLACE VIEW \`${NEW_NAME}\`.\`${view}\` AS ${defs[0].def}`);
        await conn.query(`DROP VIEW \`${OLD_NAME}\`.\`${view}\``);
        console.log(`Moved view: ${view}`);
      }
    }

    await conn.query(`DROP DATABASE \`${OLD_NAME}\``);
    console.log(`Dropped old database ${OLD_NAME}`);
    console.log(`Done. Active database is now ${NEW_NAME}`);
  } finally {
    await conn.end();
  }
}

main().catch((err) => {
  console.error('Rename failed:', err.message);
  process.exit(1);
});
