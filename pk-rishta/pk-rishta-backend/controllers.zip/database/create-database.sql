-- Create / select PK Rishta MySQL database
-- Name: pkrishta_pk_rishta_db

CREATE DATABASE IF NOT EXISTS pkrishta_pk_rishta_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE pkrishta_pk_rishta_db;
